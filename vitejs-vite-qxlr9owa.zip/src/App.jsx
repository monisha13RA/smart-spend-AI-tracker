import { useState, useEffect } from 'react';
import './App.css';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';

export default function App() {
  const [transactions, setTransactions] = useState(() => {
    try {
      const savedTransactions = localStorage.getItem('smartspend-transactions');

      return savedTransactions !== null
        ? JSON.parse(savedTransactions)
        : [
            {
              id: 1,
              name: 'Groceries',
              category: 'Food',
              amount: 850,
              type: 'Expense',
            },
            {
              id: 2,
              name: 'Monthly allowance',
              category: 'Income',
              amount: 8000,
              type: 'Income',
            },
            {
              id: 3,
              name: 'Bus pass',
              category: 'Travel',
              amount: 500,
              type: 'Expense',
            },
          ];
    } catch {
      return [
        {
          id: 1,
          name: 'Groceries',
          category: 'Food',
          amount: 850,
          type: 'Expense',
        },
        {
          id: 2,
          name: 'Monthly allowance',
          category: 'Income',
          amount: 8000,
          type: 'Income',
        },
        {
          id: 3,
          name: 'Bus pass',
          category: 'Travel',
          amount: 500,
          type: 'Expense',
        },
      ];
    }
  });

  useEffect(() => {
    localStorage.setItem(
      'smartspend-transactions',
      JSON.stringify(transactions)
    );
  }, [transactions]);

  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState('Expense');
  const [category, setCategory] = useState('Food');
  const [monthlyBudget, setMonthlyBudget] = useState(() => {
    try {
      const savedBudget = localStorage.getItem('smartspend-monthly-budget');
      return savedBudget !== null ? Number(savedBudget) : 5000;
    } catch {
      return 5000;
    }
  });

  const [budgetInput, setBudgetInput] = useState('');

  useEffect(() => {
    localStorage.setItem('smartspend-monthly-budget', String(monthlyBudget));
  }, [monthlyBudget]);

  const monthlyExpenses = transactions
    .filter((t) => {
      if (t.type !== 'Expense') return false;

      // Existing transactions have no date, so count them for the initial budget.
      if (!t.date) return true;

      const transactionDate = new Date(t.date);
      const now = new Date();

      return (
        transactionDate.getMonth() === now.getMonth() &&
        transactionDate.getFullYear() === now.getFullYear()
      );
    })
    .reduce((sum, t) => sum + t.amount, 0);

  const budgetRemaining = monthlyBudget - monthlyExpenses;

  function saveBudget(e) {
    e.preventDefault();

    const value = Number(budgetInput);

    if (budgetInput.trim() === '' || !Number.isFinite(value) || value < 0) {
      return;
    }

    setMonthlyBudget(value);
    setBudgetInput('');
  }

  const income = transactions
    .filter((t) => t.type === 'Income')
    .reduce((sum, t) => sum + t.amount, 0);

  const expenses = transactions
    .filter((t) => t.type === 'Expense')
    .reduce((sum, t) => sum + t.amount, 0);
  const expenseByCategory = Object.values(
    transactions
      .filter((t) => t.type === 'Expense')
      .reduce((groups, t) => {
        groups[t.category] ??= { name: t.category, value: 0 };
        groups[t.category].value += t.amount;
        return groups;
      }, {})
  );

  const chartColors = [
    '#168575',
    '#F59E0B',
    '#6366F1',
    '#EF4444',
    '#0EA5E9',
    '#A855F7',
    '#64748B',
    '#EC4899',
  ];
  const expensesByDate = Object.values(
    transactions
      .filter((t) => t.type === 'Expense')
      .reduce((groups, t) => {
        const date = t.date || 'undate';
        groups[date] = groups[date] || {
          date,
          total: 0,
        };
        groups[date].total += Number(t.amount);
        return groups;
      }, {})
  ).sort((a, b) => a.date.localeCompare(b.date));

  function addTransaction(e) {
    e.preventDefault();
    if (!name.trim() || !amount || Number(amount) <= 0) return;

    setTransactions([
      {
        id: Date.now(),
        name: name.trim(),
        category,
        amount: Number(amount),
        date: new Date().toISOString().slice(0, 10),
        type,
      },
      ...transactions,
    ]);

    setName('');
    setAmount('');
  }

  const money = (n) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(n);

  return (
    <main className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-icon">₹</span> SmartSpend
        </div>
        <span className="private-label">● Personal finance dashboard</span>
      </header>

      <section className="welcome">
        <p className="eyebrow">YOUR MONEY, MADE SIMPLE</p>
        <h1>
          Know your money.
          <br />
          <span>Own your future.</span>
        </h1>
        <p className="subtitle">
          Track spending, build better habits, and work towards your goals.
        </p>
      </section>

      <section className="summary">
        <article className="stat balance">
          <span>Total balance</span>
          <h2>{money(income - expenses)}</h2>
          <small>Income minus expenses</small>
        </article>
        <article className="stat">
          <span>Total income</span>
          <h2 className="green">{money(income)}</h2>
          <small>Money received</small>
        </article>
        <article className="stat">
          <span>Total expenses</span>
          <h2 className="red">{money(expenses)}</h2>
          <small>Money spent</small>
        </article>
      </section>
      <section className="panel budget-panel">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">MONTHLY PLANNING</p>
            <h2>Monthly budget</h2>
          </div>
          <span className="panel-icon">₹</span>
        </div>

        <p>
          Monthly spending: <strong>{money(monthlyExpenses)}</strong>
        </p>

        <p>
          Budget: <strong>{money(monthlyBudget)}</strong>
        </p>

        <div className="budget-track">
          <div
            className="budget-fill"
            style={{
              width: `${
                monthlyBudget > 0
                  ? Math.min((monthlyExpenses / monthlyBudget) * 100, 100)
                  : monthlyExpenses > 0
                  ? 100
                  : 0
              }%`,
            }}
          />
        </div>

        <p>
          {budgetRemaining >= 0
            ? `${money(budgetRemaining)} remaining`
            : `${money(Math.abs(budgetRemaining))} over budget`}
        </p>

        <form onSubmit={saveBudget} className="budget-form">
          <label htmlFor="monthly-budget">Set monthly budget (₹)</label>
          <input
            id="monthly-budget"
            type="number"
            min="0"
            step="1"
            value={budgetInput}
            onChange={(e) => setBudgetInput(e.target.value)}
            placeholder="Enter budget amount"
            required
          />
          <button className="add-button" type="submit">
            Save budget
          </button>
        </form>
      </section>

      <section className="content-grid">
        <section className="panel chart-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">SPENDING BREAKDOWN</p>
              <h2>Expenses by category</h2>
            </div>
          </div>

          {expenseByCategory.length === 0 ? (
            <p>Add an expense to see your chart.</p>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={expenseByCategory}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  label
                >
                  {expenseByCategory.map((entry, index) => (
                    <Cell
                      key={entry.name}
                      fill={chartColors[index % chartColors.length]}
                    />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `₹${value}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </section>
        <section className="panel chart-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">SPENDING TRENDS</p>
              <h2>Expenses over time</h2>
            </div>
          </div>

          {expensesByDate.length === 0 ? (
            <p>Add an expense to see your spending trend.</p>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={expensesByDate}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value) => `₹${value}`} />
                <Line
                  type="monotone"
                  dataKey="total"
                  stroke="#168575"
                  strokeWidth={3}
                  dot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </section>
        <article className="panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">RECORD KEEPING</p>
              <h2>Add a transaction</h2>
            </div>
            <span className="panel-icon">＋</span>
          </div>

          <form onSubmit={addTransaction}>
            <label>Transaction name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Lunch, salary"
              required
            />

            <label>Amount (₹)</label>
            <input
              type="number"
              min="1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              required
            />

            <label>Transaction type</label>
            <select value={type} onChange={(e) => setType(e.target.value)}>
              <option>Expense</option>
              <option>Income</option>
            </select>

            <label>Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option>Food</option>
              <option>Travel</option>
              <option>Shopping</option>
              <option>Bills</option>
              <option>Education</option>
              <option>Entertainment</option>
              <option>Health</option>
              <option>Other</option>
            </select>

            <button className="add-button" type="submit">
              + Add transaction
            </button>
          </form>
        </article>

        <article className="panel transactions-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">YOUR ACTIVITY</p>
              <h2>Recent transactions</h2>
            </div>
            <span className="count">{transactions.length} records</span>
          </div>

          <div className="transaction-list">
            {transactions.map((t) => (
              <div className="transaction" key={t.id}>
                <div className="transaction-icon">
                  {t.type === 'Income' ? '↙' : '↗'}
                </div>
                <div className="transaction-info">
                  <strong>{t.name}</strong>
                  <span>
                    {t.category} · {t.type}
                  </span>
                </div>
                <strong className={t.type === 'Income' ? 'green' : 'red'}>
                  {t.type === 'Income' ? '+' : '−'}
                  {money(t.amount)}
                </strong>
                <button
                  className="delete-button"
                  type="button"
                  aria-label={'Delete ' + t.name}
                  onClick={() =>
                    setTransactions(
                      transactions.filter((item) => item.id !== t.id)
                    )
                  }
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="tip">
        <span className="tip-icon">✦</span>
        <div>
          <strong>Your smart money tip</strong>
          <p>
            {expenses > 0
              ? `You've recorded ${money(
                  expenses
                )} in expenses. Review your transactions regularly to spot spending patterns.`
              : 'Start recording your spending to get helpful money insights.'}
          </p>
        </div>
      </section>

      <footer>SmartSpend · A simpler way to understand your money</footer>
    </main>
  );
}
